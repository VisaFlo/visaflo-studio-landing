# VisaFlo Studio: Top 50 확장 콘텐츠 포맷 분석

조사일: 2026-09-30. 기존 2026-09-28 구독자 Top 50의 멤버십과 순서를 유지했다. 순위나 구독자 기준은 변경하지 않았다.

## 결과

9개 채널의 27개 표본에서 시작한 자료를, 50개 채널·7,558개 최근 업로드·179개 제목/썸네일 표본으로 확장했다. 145개는 채널별 조회수 상위 3개(영상이 3개 미만이면 전부), 34개는 추가 상대 성과 표본이다. 상대 성과 표본 전체 78개 중 44개는 상위 조회수 표본과 겹친다.

30개 영상/29개 채널의 스토리보드 표본과 설명란을 직접 확인했다. 9개 영상의 공개 상위 댓글 80개도 읽었다. 기존 10개 자동 자막 표본은 재사용했고, 새 자막은 YouTube의 응답 제한으로 확보하지 못했다. 전체 영상을 연속 재생한 연구가 아니다.

## 기존 가이드에서 바꿀 점

1. 기존 여섯 포맷에 단계별 과정, 실수 점검, 고객 사례를 더해 아홉 개로 확장한다.
2. 비유형은 한 채널의 한 표본뿐이다. 반복된 성공 공식으로 일반화하지 않고 독특한 창작 후보로 소개한다.
3. 생활/유머/행사 등 비이민 주제 18개를 전문 설명 포맷의 근거로 섞지 않는다. 조회수 자체를 상담 전환으로 해석하지 않는다.
4. 직업·언어권·사례 상황을 좁힌 소재가 나타난다. 의사 면허, 배우자 재신청, 언어권 세미나, 대기 순서 질문 등 서로 다른 시청자의 문제를 분리한다.

## 계정과 영상 성과를 읽는 방법

최근 업로드 조회수는 조사 시점의 누적 조회수를 최근 365일에 게시된 영상들에 합산한 값이다. 기간 중 채널 전체가 얻은 조회수가 아니다. 조회수 중앙값, 업로드량, 긴 라이브 여부를 함께 본다. <=3분은 길이 구간이고 Shorts 판정이 아니다.

상대 조회수는 같은 채널·게시 후 경과 기간 구간·길이/라이브 구간의 다른 영상 중앙값과 비교한다. 다른 영상이 5개 이상인 경우에만 계산하며, 상대 표본은 게시 후 30일 이상·100회 이상 조회 영상에서 뽑았다. 이는 탐색 지표다. 첫 24시간 성과, 유지율, 클릭률, 광고 유입, 전환을 알 수 없으므로 인과관계나 유기적 성장으로 표현하지 않는다.

YouTube 공식 가이드도 서로 다른 콘텐츠 유형의 성과를 분리해 비교하도록 권한다: https://support.google.com/youtube/answer/12942217?co=YOUTUBE._YTVideoType%3Dvideo&hl=en

## 새 표본에서 읽은 세 가지 제작 전략

### 1. 단계가 많을수록 먼저 지도를 보여준다

Rashid Ali의 의사 면허 영상은 21,737회. 설명란 챕터가 해외에서 할 단계, 캐나다 내 단계, 평가, 주별 면허 등을 나눈다. 샘플 프레임에는 발표자와 자료/B-roll이 섞인다. 댓글은 대체 경로, 전공, 경험, 나이, 주별 차이를 묻는다. 이민 전반 대신 하나의 직업과 과정에 집중하는 템플릿을 추가한다.

### 2. 결과 사진보다 과정이 사례를 만든다

The Immigration Lounge의 대표 영상은 192,795회. 썸네일은 두 번 거절에서 승인으로 이어지는 대비, 표본 프레임은 고객과 컨설턴트의 대화, 설명란은 앞선 거절과 파일 준비를 서술한다. 독립적으로 사건이나 승인 원인을 검증한 것은 아니다. 개인정보/결과를 임의로 만들어 넣지 않고, 승인 한 장의 나열 대신 출발 상황·검토·변경·결과와 한계를 포함하는 제작 틀을 제안한다.

### 3. 댓글의 다음 질문을 다음 편으로 쓴다

Omer Khalil 댓글에는 단순한 체크리스트 요청, Rashid Ali 댓글에는 경로/조건 질문, Zeste 댓글에는 직업·지역별 후속 설명 요청이 있다. 이 자료에서 읽은 질적 요청이며, 표본 전체의 수요 비율로 계산하지 않았다. 다음 주제와 리드 마그넷을 연결할 근거로 쓴다.

## 표본 포장 분류 (제목/썸네일 기준)

- personal-or-community: 20개 표본 / 11개 채널

- firm-or-event-promotion: 19개 표본 / 12개 채널

- policy-or-news-update: 46개 표본 / 27개 채널

- claim-or-misconception: 10개 표본 / 8개 채널

- specific-question-or-explainer: 28개 표본 / 16개 채널

- process-or-checklist: 10개 표본 / 8개 채널

- decision-or-comparison: 5개 표본 / 5개 채널

- analogy: 1개 표본 / 1개 채널

- qa-or-expert-discussion: 12개 표본 / 8개 채널

- source-or-analysis: 7개 표본 / 5개 채널

- risk-or-mistake-check: 14개 표본 / 10개 채널

- client-outcome-story: 5개 표본 / 2개 채널

- office-humour: 2개 표본 / 1개 채널

이 분류는 다국어 제목과 썸네일을 수동 검토한 주된 약속의 분류다. 자막으로 검증된 대본 형식 빈도나 전체 업로드 분포가 아니다. 표본이 상위 조회수/상대 표본이므로 성공 확률·전환 순위로 해석하지 않는다.

## 30개 영상의 실제 확인 내용

### KAN Immigration / E93NxmltLZ0

[Claim-versus-confirmation framing](https://www.youtube.com/watch?v=E93NxmltLZ0) / 90,605 views

Vertical presenter, article/media inserts and caption overlays in sampled frames.

Description distinguishes an announcement from confirmed application details.

Description: firm contact and website.

### The Immigration Lounge / ya1UbJWgHpo

[Refusals-to-approval outcome](https://www.youtube.com/watch?v=ya1UbJWgHpo) / 192,795 views

Sampled frames show a client and consultant standing together, with an approval caption.

Description recounts two refusals, revised preparation and an eventual approval. This is the creator’s account; the study does not verify the case outcome or cause.

Description: consultation and phone/WhatsApp.

### Rashid Ali / RpSdD4YAa_8

[A profession-specific route map](https://www.youtube.com/watch?v=RpSdD4YAa_8) / 21,737 views

Presenter with lower thirds, brief website/B-roll inserts.

Published chapters separate residency, steps outside/inside Canada, assessment, provincial licensure and exemptions.

Description and creator comment: consultation; description also asks for subscription.

### Omer Khalil / COJQt-3BOyE

[A small choice with a consequential risk](https://www.youtube.com/watch?v=COJQt-3BOyE) / 52,338 views

Presenter alternates with explanatory rule/checklist slides and supporting B-roll.

Sampled slides separate declaration, examination and reasons; the updated description supplies source links and qualification of the claim.

Description: source/firm guide and contact.

### Amarjot Singh / fO9MJNLJmCY

[A suspicious-document warning](https://www.youtube.com/watch?v=fO9MJNLJmCY) / 6,175 views

Call participant avatars and a shared document appear in sampled frames.

Title and thumbnail identify an allegedly fake visa; frames support a document-and-call layout, not a verified fraud finding.

Description: WhatsApp contact.

### Marjorie Quintos / Wn3s-5Os8Iw

[A choice between two pathways](https://www.youtube.com/watch?v=Wn3s-5Os8Iw) / 8,190 views

Presenter alternates with PR-versus-EB-3 comparison and profile-fit slides.

Description lists eligibility, stages, timelines, employer and family factors.

Description and creator comment: assessment; creator comment asks viewers which pathway they consider.

### Sober Immigration / 8UIhSoQBJNo

[A complex topic as recurring questions](https://www.youtube.com/watch?v=8UIhSoQBJNo) / 24,522 views

Two-person podcast/interview layout, supporting B-roll and brief section graphics.

The author’s chapter list names roughly twenty questions and checklist sections across a forty-minute video.

Description: firm contact.

### North Horizon Immigration / yztPBdOkdj0

[A named language community and event](https://www.youtube.com/watch?v=yztPBdOkdj0) / 137,196 views

Presenter with seminar page inserts, city/event cards and a QR code.

Description directs Moroccan/francophone viewers to dated seminars or an online consultation.

Description and creator comment: event registration or consultation.

### DecisionMade / 4MAS8wJdcQo

[A policy question with live discussion](https://www.youtube.com/watch?v=4MAS8wJdcQo) / 6,694 views

Presenter on one side and a live-comment panel on the other in sampled frames.

Title asks how long a French-language policy can continue; this is a long-form discussion, not a quick explainer.

Description: consultation website.

### Zeste Immigration / UPke5gn4n8U

[An alternative route for a specific problem](https://www.youtube.com/watch?v=UPke5gn4n8U) / 28,573 views

Office talking head with firm branding and a social/contact end card.

Description segments the audience by province, job and status; viewer comments ask profile-specific follow-ups and request another topic.

Description: appointment, products and a free course.

### Valery Kamdem / fxwherZRdxQ

[A precise waiting-time question](https://www.youtube.com/watch?v=fxwherZRdxQ) / 4,561 views

Simple fixed presenter setup with gestures; no complex graphics in the sampled frames.

Title asks about waiting after medical/biometrics. Comments discuss anxiety, sequence and long waits.

Description: WhatsApp.

### Trulink Immigration / Ndi1JiVlnOA

[Correct one misunderstood distinction](https://www.youtube.com/watch?v=Ndi1JiVlnOA) / 92,526 views

Vertical presenter with large opening title and captions.

Description distinguishes visa validity from permitted stay. This study analyses the framing, not current policy correctness.

A viewer asks about relocation and work permission; no explicit CTA was found in the supplied description.

### Jaspreet Kaur / 0GHhfhgsY2Y

[Two applications with different conditions](https://www.youtube.com/watch?v=0GHhfhgsY2Y) / 211 views

Presenter with application/permit imagery, captions and a connection end card.

Description separates the two applications and names timing, occupation and relationship evidence as considerations.

Description: keyword DM, phone and website.

### Anyvisa Immigration / ebbbNAWIIBU

[An everyday food contrast](https://www.youtube.com/watch?v=ebbbNAWIIBU) / 120,302 views

Presenter alternates with restaurant, consultation and preparation scenes.

Earlier automatic captions connect the analogy to service strategy and preparation.

Earlier caption analysis: share/subscribe.

### Anyvisa Immigration / 5hlyz_NbQXQ

[A numbered question promise](https://www.youtube.com/watch?v=5hlyz_NbQXQ) / 83,938 views

Presenter and bright numbered question cards in sampled frames.

Earlier captions pair five questions with explanations.

Earlier caption analysis: invite viewer questions.

### Immigration.ca / 2VCGK2_JD88

[A narrowly named ancestry audience](https://www.youtube.com/watch?v=2VCGK2_JD88) / 279 views

Outdoor presenter with captions and a firm end card.

Title/description identify UK residents and ancestry; this is a short audience-specific introduction.

Description and end card: firm website.

### Ask Kubeir / Ts_oGAtIVA8

[A circulating claim and its uncertainty](https://www.youtube.com/watch?v=Ts_oGAtIVA8) / 39,003 views

Vertical presenter and subtitles, with minimal scene changes.

Earlier captions distinguish known details, unknowns and a planning takeaway.

Earlier caption analysis: planning next check.

### Sahil Sayal / ZFWBhAD27kI

[Source-led policy interpretation](https://www.youtube.com/watch?v=ZFWBhAD27kI) / 26,408 views

Presenter holding papers, then explanatory summary cards beside the presenter.

Earlier caption analysis supports document context and implications.

Earlier caption analysis: contact/consultation.

### LMRT Immigration / aeydCXiShOI

[A single study-related topic](https://www.youtube.com/watch?v=aeydCXiShOI) / 240,130 views

Arabic topic slide beside the presenter, followed by the presenter.

Earlier automatic captions support a topic-led study explainer with context and contact invitation.

Earlier caption analysis: firm contact.

### Immiland / ksAWY_xSy4E

[A process promise plus scam concern](https://www.youtube.com/watch?v=ksAWY_xSy4E) / 63,320 views

Presenter, name/credential lower third and a process summary card.

Earlier captions describe steps for work planning and caution around scams.

Description: contact/firm channels; earlier caption study supports service invitation.

### Fernando Torres Canada / kLEtEgEPrA0

[A named professional audience](https://www.youtube.com/watch?v=kLEtEgEPrA0) / 89,534 views

Two-expert layout with professional B-roll and event/contact artwork at the end.

Title names medical and related professions; the layout supports expert discussion and promotion.

Visible end card: professional-opportunity event/firm invitation.

### Canadian Immigration Institute / Uvz58ZIdIEU

[A source-based long explanation](https://www.youtube.com/watch?v=Uvz58ZIdIEU) / 12,441 views

Long opening slate, document screen with presenter inset, then presenter.

Earlier captions support source context and policy explanation across a long livestream.

Earlier caption analysis: consultation/firm invitation.

### Milele Immigration / kun_W7Y5Oek

[A risk attached to an official letter](https://www.youtube.com/watch?v=kun_W7Y5Oek) / 2,032 views

Presenter with a large opening urgency/topic overlay.

Title and overlay name procedural-fairness/refugee issues. No new speech transcript was available.

Description/overlay primarily name the topic; no full spoken CTA was confirmed.

### Nazmul Canada / wLEHfYPeCsc

[A named procedural topic](https://www.youtube.com/watch?v=wLEHfYPeCsc) / 89,917 views

Presenter with topic captions, an on-screen document and a firm-service end card.

Title identifies PRRA; frames support document-and-presenter explanation. No new speech transcript was available.

Visible firm/contact end card.

### Syn Amanuel / 0rwANJwIzgM

[A policy impact on backlogs](https://www.youtube.com/watch?v=0rwANJwIzgM) / 21,244 views

Virtual-studio presenter with chart/table panels and target figures.

Title names backlogs and the plan; visual panels make the evidence visible. No new speech transcript was available.

Firm/studio branding visible; spoken CTA not confirmed.

### GOOSELAW Immigration / IzxLMX33oxc

[Refusal risk and prevention](https://www.youtube.com/watch?v=IzxLMX33oxc) / 2,572 views

Simple presenter shot with captions.

Title promises a refusal-risk explanation; sampled captions indicate a consequence/factor discussion.

Description: firm links/contact.

### Clairevision Immigration / _IbweNp1df0

[A named francophone audience](https://www.youtube.com/watch?v=_IbweNp1df0) / 3,096 views

Presenter with a lower-third strip and occasional document imagery.

Title names francophones and policy changes; body sequence was not transcribed.

Description: firm/social contact.

### Broadview Immigration / Vzv66NZbVGI

[A consultation scene](https://www.youtube.com/watch?v=Vzv66NZbVGI) / 267 views

One person seated at a desk speaking to someone out of frame.

Title and frames support a meeting scene; no broader successful-format claim is made from 267 views.

No spoken CTA confirmed.

### Enloja / gXoIwFX1ubM

[A short programme-topic clip](https://www.youtube.com/watch?v=gXoIwFX1ubM) / 1,806 views

Close presenter shot with a short caption/lower third.

Title names Express Entry; no detailed narrative inference is made from these frames.

Firm identity visible; spoken CTA not confirmed.

### Andy Luu RCIC / IGtEta4yp-o

[One concrete visitor situation](https://www.youtube.com/watch?v=IGtEta4yp-o) / 1,283 views

Presenter with large question/term cards, including an application term.

Vietnamese title poses staying longer as a visitor; sampled overlays support the single-situation format.

Description names firm contact; spoken CTA not confirmed.

## 파일

- channel-profiles.csv/json: 50개 채널의 업로드량·성과·표본 포장·대표 영상
- coded-samples.csv/json: 179개 표본과 분류·근거 범위
- deep-notes.json: 30개 프레임/설명란 확인 기록
- research-coverage.json: 실제 확보·검토 수
- inventory.csv/json: 7,558개 데이터 기록
- comments.json: 로컬 연구용 공개 댓글 (공유 패키지에는 원문을 넣지 않음)
- caption-coverage.json: 새 자막 실패 기록
- storyboard-coverage.json: 표본 프레임 경로와 영상 챕터
- 원본 스토리보드, 설명란, 자막 전체는 공유용 ZIP에 넣지 않는다.
